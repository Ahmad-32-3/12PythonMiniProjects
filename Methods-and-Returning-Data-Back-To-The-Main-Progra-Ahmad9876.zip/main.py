from functions import square_area, circle_area, rectangle_area, big_5

while True:
  choice = -1
  while choice < 0 or choice > 5:
    #Introduces calculator and stores user input
    print("\nWelcome to my Math Calculator. Choose from the options 1-4")
    print("1. Calculate the area of a square")
    print("2. Calculate the area of a circle ")
    print("3. Calculate the area of a rectangle")
    print("4. Use big 5 equations to solve a physics problem")
    print("5. Exit the program\n")
    try: 
      choice = int(input("Enter your choice 1-4: " ))
    except ValueError:
      print("Invalid input, please try again")
      continue

    # Invalidates values that are less than 0 and greater than 5
    if choice < 0 or choice > 5:
      print("Invalid input, please try again")
  
  # Uses if statements to ask for needed information and output areas or unknowns
  if choice == 1:
    side_length = float(input("Enter the side of the square: "))
    area = square_area(side_length)
    print(f"The area of the square is {area:.2f}\n")
  elif choice == 2:
    radius = float(input("Enter the radius of the circle: "))
    area = circle_area(radius)
    print(f"The area of the circle is {area:.2f}")
  elif choice == 3:
    length = float(input("Enter the length of the rectangle: "))
    width = float(input("Enter the width of the rectangle: "))
    area = rectangle_area(length, width)
    print(f"The area of the rectangle is {area:.2f}")
  elif choice == 4:
    print("\nNote that the user must select a direction as positive and input all values in accordance to that. For instance, if up is postiive than the acceleration due to gravity is negative. Simply press enter to signify you are not given a value. \n")
    result, arg, names, units = big_5()
    print(f"The {names[arg]} is {result:.3f} {units[arg]}")
  # Uses break to exit program  
  else:
    print("Thank you for using my calculator!")
    break
  
    
    