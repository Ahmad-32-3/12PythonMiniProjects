# Instructions  

 Earlier in this activity, you created a program that performed a variety of math calculations.

The program displayed a menu to the user that allowed him or her to select from 3 different mathematical calculations. Once the user made a selection, the program then prompted the user for the required data, performed the calculation, and output the data in a user-friendly format. The program then looped back and presented the user with the menu again. The menu also had an option that allowed the user to exit the program.

It is now time to create a similar program with a few important differences:

* This project should use subroutines for as many tasks as possible. Consider creating subroutines to output the user menu, to obtain data from the user, to output the solutions to the calculations, etc.
* You should use methods to complete the calculations, and each subroutine will return data back to the main program, rather than output the data itself.
* You should include at least six choices for the user to select. If you need more ideas, think about any calculations that you may do frequently in any of your other classes:
    * science - electricity equations, optics, chemistry
    * food and nutrition - cups to tsp or tbsp or ml
    * tech - inch to cm
    * math
* You can re-use  what you had in the earlier assignment as long as you change them to use the return function

Think carefully about what parameters the subroutines need to accomplish in each task. Some of the data will come from the user, while other data might involve using constants.

Before submitting your program, be sure to

* comment your code.
* include constants when necessary.
* use appropriate variable and subroutine names.
* include docstrings for each subroutine.

Functions should be defined at the top of your program before entering the loop. 
  