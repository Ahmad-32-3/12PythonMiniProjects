import math
from collections import defaultdict

def square_area(side_length):
  """function square_area takes integer side-length and returns area of a square"""
  area = side_length**2
  return area

def circle_area(radius):
  """fucntion circle_area takes integer radius and returns area of a circle"""
  area = math.pi * radius**2
  return area

def rectangle_area(length, width):
  """function rectangle_area takes integer length and width and returns area of a rectangle"""
  area = length * width
  return area
  
def quadratic_formula(a,b,c):
  """function quadratic_formula takes three variables returns answer using the quadratic formula"""
  t1, t2 = 0, 0
  try: 
    t1 = (-b + math.sqrt(b ** 2 - 4 * a * c)) / (2 * a)
    t2 = (-b - math.sqrt(b ** 2 - 4 * a * c)) / (2 * a)
  except ValueError:
    print("Numbers are needed, not letters, please try again")
  return t1, t2
    
def eq1(variables, choice):
  """function eq1 takes in a list of floats and a string to return the unknown float"""
  if choice == "d":
      return variables["vi"] * variables["t"] + 0.5 * variables["a"] * variables["t"] ** 2
  elif choice == "vi":
      return (variables["d"] - 0.5 * variables["a"] * variables["t"] ** 2) / variables["t"]
  elif choice == "a":
      return (2 * (variables["d"] - variables["v"] * variables["t"])) / variables["t"] ** 2
  elif choice == "t":
      ans1, ans2 = quadratic_formula (0.5*variables["a"], variables["vi"], variables["d"])
      print(f"The time is {ans1:.3f} s")
      return ans2

def eq2(variables, choice):
  """function eq2 takes in a list of floats and a string to return the unknown float"""
  if choice == "d":
      return variables["vf"] * variables["t"] - 0.5 * variables["a"] * variables["t"] ** 2
  elif choice == "a":
      return (-2 * (variables["d"] - variables["vf"] * variables["t"])) / variables["t"] ** 2
  elif choice == "vf":
      return (variables["d"] + 0.5 * variables["a"] * variables["t"] ** 2) / variables["t"]
  elif choice == "t":
      ans1, ans2 = quadratic_formula (0.5*variables["a"], variables["vi"], variables["d"])
      print(f"The time is {ans1:.3f}")
      return ans2
    
def eq3(variables, choice):
  """function eq3 takes in a list of floats and a string to return the unknown float"""
  if choice == "vf":
      return math.sqrt(variables["vi"] ** 2 + (2 * variables["a"] * variables["d"]))
  elif choice == "vi":
      return math.sqrt(variables["vf"] ** 2 - (2 * variables["a"] * variables["d"]))
  elif choice == "a":
      return (variables["vf"] ** 2 - variables["vi"] ** 2) / (2 * variables["d"])
  elif choice == "d":
      return (variables["vf"] ** 2 - variables["vi"] ** 2) / (2 * variables["a"])

def eq4(variables, choice):
  """function eq4 takes in a list of floats and a string to return the unknown float"""
  if choice == "d":
      return ((variables["vi"] + variables["vf"]) / 2) * variables["t"]
  elif choice == "vi":
      return ((2 * variables["d"]) / variables["t"]) - variables["vf"]
  elif choice == "vf":
      return (2 * variables["d"]) / variables["t"] - variables["vi"]
  elif choice == "t":
      return (2 * variables["d"] - variables["vi"]) / variables["vf"]

def eq5(variables, choice):
  """function eq5 takes in a list of floats and a string to return the unknown float"""
  if choice == "vf":
      return variables["vi"] + variables["a"] * variables["t"]
  elif choice == "vi":
      return variables["vf"] - variables["a"] * variables["t"]
  elif choice == "a":
      return (variables["vf"] - variables["vi"]) / variables["t"]
  elif choice == "t":
      return (variables["vf"] - variables["vi"]) / variables["a"]

def big_5():
  """big_5 returns the answer to physics equations involving the big 5"""
  variables = defaultdict(float)
  
  while True:

    # Asks user to input variables
      try:
          choice = input("What variable would you like to solve for(a, vi, vf, t, d): ")
      except ValueError:
          print("Invalid input, try again")
          continue

      if choice != "a":
          try:
              variables["a"] = float(input("What is acceleration?(m/s^2): "))
          except ValueError:
              unknown = "a"

      if choice != "t":
          try:
              variables["t"] = float(input("What is time?(s): "))
          except ValueError:
              unknown = "t"

      if choice != "vi":
          try:
              variables["vi"] = float(input("What is initial velocity?(m/s): "))
          except ValueError:
              unknown = "vi"
            
      if choice != "vf" and len(variables) < 3:
          try:
              variables["vf"] = float(input("What is final velocity?(m/s): "))
          except ValueError:
              unknown = "vf"
      elif choice != "vf":
        unknown = "vf"
      else:
        unknown = "d"
        
      if choice != "d" and len(variables) < 3:
          try:
              variables["d"] = float(input("What is displacement?(m): "))
          except ValueError:
              unknown = "d"
      elif choice != "d":
        unknown = "d"
            
      # Selects which equation to use depending on what variable is unknown
      if unknown == "vf":
          run = eq1(variables, choice)
      elif unknown == "vi":
          run = eq2(variables, choice)
      elif unknown == "t":
          run = eq3(variables, choice)
      elif unknown == "a":
          run = eq4(variables, choice)
      elif unknown == "d":
          run = eq5(variables, choice)
      break
    
  big_five_choices = {
  "a": "acceleration", 
  "vi": "initial velocity",
  "vf": "final velocity",
  "t": "time",
  "d": "displacement"
}
  big_five_units = {
  "a": "m/s^2",
  "vi": "m/s",
  "vf": "m/s",
  "t": "s",
  "d": "m"
}
  return run, choice, big_five_choices, big_five_units
