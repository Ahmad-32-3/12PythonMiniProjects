intro = """
Please enter your choice:

1... Count from 0 to 10 by 1
2... Count from 100 to 0 by 10
3... Count from 50 to 500 by 50
4... Count from 6000 to 1000 by 1000
"""

print(intro)
choice = int(input("input just the number of the option you want.\n"))

if choice == 1:
    print("You have chosen to count from 0 to 10 by 1")
    for i in range(0,11,1):
      print(i)

elif choice == 2:
    print("---------------------------")
    print("You have chosen to count from 100 to 0 by 10")
    for j in range(100,-10,-10):
      print(j)

elif choice == 3:
    print("---------------------------")
    print("You have chosen to count from 50 to 500 by 50")
    for k in range(50,550,50):
      print(k)

elif choice == 4:
    print("---------------------------")
    print("You have chosen to count from 6000 to 100 by 1000")
    for number in range(6000,0,-1000):
        print(number)

else:
    "None of the options were selected. Code terminated."


