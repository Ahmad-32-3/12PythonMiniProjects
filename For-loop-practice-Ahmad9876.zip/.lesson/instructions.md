# Instructions  

 Your task is to create a program that prompts the user with the following user menu:

Please enter your choice:

1... Count from 0 to 10 by 1
2... Count from 100 to 0 by 10
3... Count from 50 to 500 by 50
4... Count from 6000 to 1000 by 1000
 

When the user makes his or her choice, the program will then perform the task indicated by executing a for loop. It is your job to determine how you will perform each task with a for loop. You will have to work with the initial value of the for loop counter and its final value, and then increase or decrease the counter with each pass through the loop.


Make sure to run the test when you finish.
There are 4 tests that the code needs to pass, one for each situation.
  