#import statements 
from functions import currency

# Stores user input for vrorbits
while True:
  try: 
    vrorbits = float(input("Please enter the number of vrorbits you would like to exchange: "))
  except ValueError:
    print("Invalid input, please try again, only numbers no letters")
  else:
    break
  
# Uses function to find how much of each coin there is
drobzits, clickwicks, gazoontights, frazoints, blointoints, leftover_vrorbits = currency(vrorbits)

# Print out currency exchange
print(f"The number of drobzits are: {drobzits:.2f}")
print(f"The number of clickwicks are: {clickwicks:.2f}")
print(f"The number of gazoontights are: {gazoontights:.2f}")
print(f"The number of frazoints are: {frazoints:.2f}")
print(f"The number of blointoints are: {blointoints:.2f}")
print(f"The number of leftover vrorbits are: {leftover_vrorbits:.2f}")