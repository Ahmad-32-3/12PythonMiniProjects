#example function
def drobzit(vrobits):
    """Takes the number of vrobits and returns the number of drobzits that make up the number and the change of vrobits"""
    remainder = vrobits % 100_000
    drobzit =  int((vrobits - remainder)/100_000)
    return drobzit, remainder #note that this returns 2 values

# Example of using a function that returns 2 values
# 'a' stores the first value that is returned
# 'b' stores the second value that is returned
a,b = drobzit(542854) 