# Instructions  

 Planet Zirboin is a planet very far away (perhaps that’s why you’ve never heard of it).

![image](image.png)

The planet uses money, much like you do on Earth, but their system is a little different in that they only have 6 different coins. The lowest valued coin is a vrobit.

The values for each of the other coins on Planet Zirboin are as follows:

* 1 drobzit coin is equal to 100,000 vrobits
* 1 clickwick coin is equal to 50,000 vrobits
* 1 gazoontight coin is equal to 10,000 vrobits
* 1 frazoint coin is equal to 1,000 vrobits
* 1 blointoint coin is equal to 500 vrobits

Margaret is an alien living on Planet Zirboin who runs a travel agency that has had moderate success over the years. To supplement her travel agency income, she also collects vrobits that fall in between the cushions of alien couches. (Yes, that happens everywhere, even in other galaxies!)

She is on her way to ZirboinFinancial (it’s an alien bank) where she is going to exchange the vrobits that she has been saving over the last few years. She wants to exchange her vrobits in a way that leaves her with the fewest number of coins.

Margaret hands over ***542,854*** vrobits to the alien bank cashier, but there is a problem. The bank staff can’t figure out how to calculate the number of different coins they should give to Margaret. It’s alien anarchy!

Your task is to design and develop financial software for ZirboinFinancial. The software you develop should allow the bank tellers to input the number of vrobits being exchanged.

The program should then output the number of drobzits, clickwicks, gazoontights, frazoints, blointoints and leftover vrobits that are required.

If you’re curious about why or how ZirboinFinancial has gotten in touch with you to create this software, let’s just say that your teacher knows a guy who knows this girl who delivers pizza to a guy that knows an alien, who is cousins with ZirboinFinancial’s night time security guard.

