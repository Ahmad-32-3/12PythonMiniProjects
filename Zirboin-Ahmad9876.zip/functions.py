def currency(vrorbits):
  """function currency takes vrorbits and returns drobzits, clickwicks, gazoontights, frazoints, blointoints and leftover vrorbits"""
  # Use operators to find integer value and remainder value of vrorbits 
  drobzits = vrorbits // 100000
  leftover_vrorbits = vrorbits % 100000

  clickwicks = leftover_vrorbits // 50000
  leftover_vrorbits %= 50000

  gazoontights = leftover_vrorbits // 10000
  leftover_vrorbits %= 10000

  frazoints = leftover_vrorbits // 1000
  leftover_vrorbits %= 1000

  blointoints = leftover_vrorbits // 500
  leftover_vrorbits %= 500

  return drobzits, clickwicks, gazoontights, frazoints, blointoints, leftover_vrorbits


  

  