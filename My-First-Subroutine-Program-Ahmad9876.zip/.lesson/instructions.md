# Instructions  

  Your task is to create a program that displays to users a menu that allows them to select from three different mathematical calculations.

Once the user makes a selection, the program then prompts the user for the required data, performs the calculation, and outputs the data in a user-friendly format. The program should then loop back and present the user with the menu again. The menu should also have an option that allows the user to exit the program. This is similar to you Loops - Consolidation activity.

Your program should be written using at least 3 subroutines, one for each mathematical calculation that you have chosen. The subroutines should be written similar to the addAndOut and multAndOut subroutines above, however you can't use the examples.

The following are some suggested mathematical calculations. See if you can program some of the more complex ones:

* Finding perimeter, area or volume of specific shapes
* Determining radius, diameter, circumference of circles
* Finding averages of numbers
* Finding missing angles/sides for triangles
* Finding speed or acceleration
* Determining the midpoint or slope of a line
* Determining the factorial of a number (you might need loops)
* Determining if a number is prime (you might need loops)
* Any of your own ideas
* 
Don't use the "return" keyword yet. All your subroutines should print out the answer your calculation. We will learn to use the return keyword in the next section. 

Think carefully about what data the subroutines need to accomplish each task. Some of the data will come from the user. Other data might involve using constants.

Before submitting your program, be sure to

* comment your code.
* include constants when necessary.
* use appropriate variable and subroutine names.
