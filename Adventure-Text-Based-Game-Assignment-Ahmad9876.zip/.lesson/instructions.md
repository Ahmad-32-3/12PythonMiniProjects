# Instructions  


 Your task is to create a "Choose Your Own Adventure" text-based Python game.

Your game will present to the user a plot line and an initial decision to make. The user will enter in data to indicate his or her choice, and then the story should continue to present the user with plot twists, new characters and decisions. All choices should lead to final outcomes: some successful, others not.

You decide the context, theme or plot of your story. Some suggestions include:

  The user is an astronaut trying to reach Mars.
  
  The user is a pirate trying to discover a buried treasure.
  
  The user is a movie star living in L.A.
  
  The user is in a haunted house and must get out.
  
  The user has lost his or her phone and is trying to find it.
  
  The user is a country leader trying to make the best decisions for the people.
  
  The user is making career choices.
  
  The user is a driver in an ‘around the world’ rally race.
  
  The user is making life choices after winning the lottery.
  
  The user is a sales clerk trying to sell to customers.
  
  The user is a plane crash survivor trying to stay alive.
  
  The user is a crime fighter trying to solve a mystery.
  
  The user is a Canadian traveller trying to get home after a hurricane.
  
  The user is a Grade 9 student looking for his or her first class.
  
  The user is a Grade 11 math student deciding what method to use to factor a quadratic expression.
  
  The user is running a 3 team tournament to find a winner.


    
Start by making your flowchart first. Your game will involve several nested if-then-else statements and it will be much easier to write once you have already developed the program plot, decisions and logic.

You will be assessed on the flowchart, game, ***organization of code and programming style***. Be sure to refer to the programming style guidelines and use proper variable names, spacing, indenting, commenting, etc.

Also, make sure that you make it clear to the users what information is needed to enter to make their decisions. If you ask them a yes or no question, should they respond with Yes, or yes, or YES, or Y? This has to be made very clear.

You will submit your completed flowchart and game to your teacher.
  