from moffat import slow_print

# This function prompts the user to pick what number their class code starts with; dictating floorlevel
def floorlevel():
  slow_print("What number does your room number start with?")
  slow_print("a. Does it start with a 1?")
  slow_print("b. Does it start with a 2?")
  slow_print("c. Does is start with a 3?")
  slow_print("d, Does it start with a 4?")
  choice1 = input("Enter your choice (a, b, c or d): ")
  return choice1

# This function prompts the user to pick what the second number in their three digit classroom code is; dictating what hall they will be in
def hallway():
  slow_print("a. The second digit is 1")
  slow_print("b. The second digit is 2")
  slow_print("c. The second digit is 3")
  choice2 = input("Enter your choice (a, b or c): ")
  return choice2

# This function promps the user to pick what the last number in their three digit classroom is; dictating what side of the hall the class will be in
def rightorleft():
  slow_print("\na. The third digit is odd")
  slow_print("b. The third digit is even")
  choice3 = input("Enter your choice (a or b): ")
  return choice3
    
