# Intialize functions
from moffat import clear, ask_clear, slow_print
from functions import hallway, floorlevel, rightorleft
# Name: Muhammad Ahmad NOTE: Assignment was handed in late because I was waiting for an email response in regards to a question 

# Title of Game: First Day at School

# Print Introduction
slow_print("Welcome to technology heights, the high school that specializes in technology and STEM! I'm your virtual assistant program. I help students new to the high school find their classrooms!\n As you see, you have a three digit code on your planner known as your room number, your class will commence in that room.")
ask_clear()
         
# First choice, using the clear function only hear is a deliberate choice. The function floorlevel contains the necessary code to prompt the user to input a choice in accordance to the questions.
choice1 = floorlevel()
clear()

if choice1 == "a" or choice1 == "1":
  slow_print("Your class is on the first floor!\nWhat is the second digit of your room number?:\n")
  
  # Second choice, use hallway function for inputs 
  choice2 = hallway()
    
  # The second digit of the students room number is 1
  if choice2 == "a" or choice2 == "1":
    slow_print("\n\nYou are in the technology hall, hall A!\nIs the third digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # Invalid input 
    else: 
      slow_print("Invalid input, please restart the program")
      
  # The second number is a 3
  elif choice2 == "c" or choice2 == "3":
    slow_print("\n\n You are in hall C, the language hall! Is the last digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The input was not a or b as prompted, restart program
    else:
      print("Invalid input, please restart program")

  # The second digit of the students room number is 2
  elif choice2 == "b" or choice2 == "2":
    slow_print(" \n\nYou are in the math hall, hall B!\nIs the third digit odd or even?")

    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    #The input was not a or b as prompted, restart program
    else:
      print("Invalid input, please restart program")

  #Input was not a, b or c as prompted
  else:
    print("Invalid input, please restart the program")

# The students room number starts with a 2
elif choice1 == "b" or choice1 == "2":
  slow_print("Your class is on the second floor!\nWhat is the second digit of your room number?: ")

  # Second choice, use hallway function for inputs 
  choice2 = hallway()
  
  # The second digit of the students room number is 1
  if choice2 == "a" or choice2 == "1":
    slow_print("\n\nYou are in the technology hall, hall A!\nIs the third digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The input given by user is not within the set parameters, stop program
    else:
      print("Invalid input, please restart program")
      
  #The second number is a 3
  elif choice2 == "3" or choice2 == "c":
    slow_print("\n\n You are in hall C, the language hall! Is the last digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The given input is not an accepted value according to the set paramets, stop program
    else:
      print("Invalid input, please restart program")
  # The second digit of the students room number is 2
  elif choice2 == "b" or choice2 == "2":
    slow_print("\n\nYou are in the math hall, hall B!\nIs the third digit odd or even?")

    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The given input is not an accepted value according to the set paramets, stop program
    else:
      print("Invalid input, please restart [program")
  # The given input was not in the peramaters given(choose choices from a,b or c)
  else:
    print("Invalid input, please restart program")
    
elif choice1 == "c" or choice1 == "3":
  slow_print("Your class is on the third floor!\nWhat is the second digit of your room number?: ")

  # Second choice, use hallway function for inputs 
  choice2 = hallway()
  
  # The second digit of the students room number is 1
  if choice2 == "a" or choice2 == "1":
    slow_print("\n\nYou are in the technology hall, hall A!\nIs the third digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The input given by user is not within the set parameters, stop program
    else:
      print("Invalid input, please restart program")
      
  #The second number is a 3
  elif choice2 == "3" or choice2 == "c":
    slow_print("\n\n You are in hall C, the language hall! Is the last digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The given input is not an accepted value according to the set paramets, stop program
    else:
      print("Invalid input, please restart program")
  # The second digit of the students room number is 2
  elif choice2 == "b" or choice2 == "2":
    slow_print("\n\nYou are in the math hall, hall B!\nIs the third digit odd or even?")

    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The given input is not an accepted value according to the set paramets, stop program
    else:
      print("Invalid input, please restart [program")
  # The given input was not in the peramaters given(choose choices from a,b or c)
  else:
    print("Invalid input, please restart program")
# Making sure that only a and b can be used as valid inputs

elif choice1 == "d" or choice1 =="4": 
  slow_print("Your class is on the fourth floor!\nWhat is the second digit of your room number?: ")

  # Second choice, use hallway function for inputs 
  choice2 = hallway()
  
  # The second digit of the students room number is 1
  if choice2 == "a" or choice2 == "1":
    slow_print("\n\nYou are in the technology hall, hall A!\nIs the third digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The input given by user is not within the set parameters, stop program
    else:
      print("Invalid input, please restart program")
      
  #The second number is a 3
  elif choice2 == "3" or choice2 == "c":
    slow_print("\n\n You are in hall C, the language hall! Is the last digit odd or even?")
    
    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The given input is not an accepted value according to the set paramets, stop program
    else:
      print("Invalid input, please restart program")
  # The second digit of the students room number is 2
  elif choice2 == "b" or choice2 == "2":
    slow_print("\n\nYou are in the math hall, hall B!\nIs the third digit odd or even?")

    # Third choice, use hallway function for inputs 
    choice3 = rightorleft()
    
    # The third digit is odd
    if choice3 == "a" or choice3 == "odd":
      slow_print("\n\nYour room is on the left side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The third digit is even
    elif choice3 == "b" or choice3 == "even":
      slow_print("\n\nYour room is on the right side of the hall, please keep walking until you find the room number that matches with your three digit code!")

    # The given input is not an accepted value according to the set paramets, stop program
    else:
      print("Invalid input, please restart [program")
  # The given input was not in the peramaters given(choose choices from a,b or c)
  else:
    print("Invalid input, please restart program")
else:
  print("Invalid input. Please restart the program.")