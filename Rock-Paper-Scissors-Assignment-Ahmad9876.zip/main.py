from random import choice

#Set rigged as false, if true than computer wins each time
rigged = True

# Sets the entire program in an infintie loop to more easily restart the program
while True: 
  # Create a list of play options
  options = ["Rock", "Paper", "Scissors"]
  
  # Get player choice
  player = input("Choose rock, paper or scissors: ").title()
  while player not in options:
      player = input("Invalid choice. Choose rock, paper or scissors: ").lower().capitalize()
   
  # Assign a play to the computer depending on if the game is rigged
  if rigged:
      # Choose option that wins
      computer = {"Rock": "Paper", "Paper": "Scissors", "Scissors": "Rock"}[player]
  else:
      # Choose a random option
      computer = choice(options)
  
  # Sets a dictionary, where the key of the item wins against the value
  winCondition = {"Rock":"Scissors", "Paper":"Rock", "Scissors":"Paper"}
  
  # Determine who wins and provide adequate response
  if winCondition[player] == computer:
    print(f"You win!\nThe player chose {player} which defeats the computer who chose {computer}")
  elif player == computer:
    print(f"Tie!\nBoth the computer and player chose {player}")
  else:
    print(f"You lose!\nThe computer chose {computer} which defeats the player who chose {player}")

  # Initializes variable to see if player wants to play again
  play_again = input("\nDo you want to play again? (yes/no)?: ").lower()

  # Determines if the input is not yes, to break the program
  if play_again != "yes":
    break
print("\nHave a nice day!")

# Improvements:
# Used a dictionary to store the winconditions. This shortened the program by many lines. The key-value pairs represent the winning relationships between the pairs.   The program knows the winner because it will look up the value the computer chose and compare it with the player. If the player chose rock, it will look at rock     in the dicitonary and see the value associated with the key. If the computer chose that value, then the player won! 
# Used a while loop to find player input so that a valid input must occur for the program to proceed
# Used a while loop to more easily restart the program
# Used f strings to more easily write out the print statements after finding out who won and why
# Special characters like \n used to make the console output look better
# The rigged function works in a unique way by utilizing dictionaries. Essentially, the player choice is assigned to the key part of the item using square brackets. And when the game is rigged, the computer always chooses the value part of the item, which beats the player!
# Handed in late while waiting for an email response