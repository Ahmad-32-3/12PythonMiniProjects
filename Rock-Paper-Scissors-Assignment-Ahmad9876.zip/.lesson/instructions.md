# Instructions  

 
Complete the Rock Paper Scissors game by following the comments provided.

Randomly have the computer choose an answer. Use the function `randint()` or `choice()` function within the `random` module to help you with this. 

Print out the choice that the user made, that the computer made, and the result of the game: win, loss, or tie. 

<br/><br/>
### To earn a level 4 on this assignment.
+ Only import the specific functions needed and not an entire module.

+ Have a variable called rigged = False as the default. If switched to True always have user lose the game. This variable should only be seen in the code and does not need be accessed through the console.

 + Add at least one other improvement or feature. Put a comment at the end of the code breifly stating how you improved the code. Some ideas are:
   + Use boolean logic operators (and, or) to flatten the nested statements
   + Use formatted strings and enhance the output
   + Any other improvement you can think of.

  