from moffat import ask_clear, slow_print
from functions import ib_level, quiz_library, randomizer, quiz_game  

# Constant for passing percentage
PASSING_PERCENTAGE = 50

# function that provides questions and answers
quiz = quiz_library()

# Convert quiz_library into list and randomizes it
list = randomizer(quiz)

# The number of questions that will be asked are 10
total_questions = 15

# Introduces game
slow_print("Welcome to the show what you know quiz game! In this game, you will show what you know about a variety of topics. There are 21 questions and you must get 50% or over to pass. Good luck!")
ask_clear()

# Code that runs game
score = quiz_game(randomizer(quiz), quiz, total_questions)

# Sets percentage
percentage = score/total_questions*100

# Function to calculate the IB level based on percentage
grading = ib_level(percentage)

# Outputs score
slow_print(f"You have scored {score}/{total_questions} which is {percentage:.2f}% Your IB level was {grading}")

# Checks if you have passed
if percentage >= PASSING_PERCENTAGE:
  slow_print("Congratulations on passing the show what you know quiz!")
else:
  slow_print("Sorry you failed :(")