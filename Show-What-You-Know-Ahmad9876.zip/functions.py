import random
from moffat import slow_print

def ib_level(percentage):
  """ib_level takes user percentage and returns it as a score out of International Baccalaureate (IB) rubric"""
  if percentage >= 97:
    return "7"
  elif percentage >= 92:
    return "6"
  elif percentage >= 84:
    return "5"
  elif percentage >= 72:
    return "4"
  elif percentage >= 61:
    return "3"
  elif percentage >= 50:
    return "2"
  else:
    return "1"

def quiz_library():
  """quiz_library returns a pool of quiz questions that can be used as a game"""
  quiz = {
  "What is the Capital of Canada?\n": "ottawa",
  "What is the most popular sport in the world?\n": ["football", "soccer"],
  "Who has won the most Ballon D'Ors?\n": ["messi", "lionel messi", "lionel"],
  "Who created python?\n": "guido van rossum",
  "What is Canada's national summer sport?\n": "lacrosse",
  "Solve the following equation for x such that x>0: 32x^2-162=0\n": ["9/4", "x=9/4"],
  "How many countries are there in the world?\n": ["195"],
  "Historically, who has engaged and initated the most proxy wars in the past few decades\n": ["united states", "america"],
  "How many provinces and territories are there in Canada?\n": "13",
  "Which country has the highest population?\n": "china",
  "Are logarithmic graphs the inverse of exponential graphs?(yes or no)\n": ["yes", "y"],
  "Can a logarithmic function have a negative argument?(yes or no)\n": "no",
  "What year did World War 2 start?\n": "1939",
  "Who was the Russian leader at the end of World War 2?\n": ["joseph stalin", "stalin", "joseph"],
  "Can electrons exist between energy levels of an atom?(yes or no)\n": "no",
  "As you move across a period of the periodic table from left to right, does atomic radius increase or decrease?\n": ["decrease", "decreases"],
  "Who is famous for creating Macbeth?\n": ["shakespeare", "william shakespeare", "william"],
  "Which country in the world has the most oil reserves?\n": "venezuela",
  "What is the smallest country in the world?\n": "vatican city",
  "At what standing is Canada for the largest countries in the world?(first, second, third e.t.c)\n": ["second", "2nd", "2"],
  "Who sold the most gaming consoles in the 2021 year?\n": ["sony"],
  "When did World War 1 end?\n": "1918",
  "What is the statue of liberty made of?\n": "copper",
  "When ideal gases collide, is kinetic energy conserved?": ["yes", "y"],
  "Is the coeffecient of friction higher in static friction or kinetic friction?": ["static", "static friction", "Fsmax"],
  "What fruit is human DNA most identical to?": ["banana", "bananas", "nanners"],
  "How many chromosomes do humans usually have?": ["46", "forty-six", "forty six"],
  "How many lagrange points are there around Earth?": ["5", "five"],
  "What state is bromine in?": "liquid",
  }
  return quiz

def randomizer(quiz):
  """randomizes the quiz dictionary and returns it as a list of keys.""" 
  quiz_keys = list(quiz.keys())
  random.shuffle(quiz_keys) # Randomizes keys in quiz
  return quiz_keys[:15] # Stops after 15 questions are asked

def quiz_game(quiz_keys, quiz, total_questions):
  """runs a quiz game that returns score, percentage and IB level of the user"""
  score = 0 
  
  for question in quiz_keys:
    print("------------------------------------------------------------------")
    slow_print(question)
    answer = quiz[question]
  
    # Gets user input and checks if it is correct
    userInput = input().lower().strip()
    while userInput == "":
      slow_print("Please enter an answer")
      userInput = input().lower().strip()
    if userInput in answer:
      slow_print("Correct!\n")
      score += 1
    else:
      slow_print(f"Incorrect, the correct answer is {answer}.\n")
    
  return score
