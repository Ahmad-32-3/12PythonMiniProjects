# Instructions  

  Your task is to create a program that uses list and loops together to do a task.

Rather than being told exactly what your program should do, you now have an opportunity to plan, develop and submit a program of your choosing.

Here is a list of possible programs you might choose to develop:

Ask the user to enter his or her favourite hockey/baseball/sports star statistics for the past 5 games and tell them the average.
Create a program that will create a list of 10 random values between 1 and 100, display it to the user and tell the user the max and min values.
Create a program that will create a list of 10 random math/science/etc. questions, AND a second list of the 10 random answers that correspond to each question. The program should then ask the user 10 random questions.

Start by doing a flow chart.

Then you can start coding!

Make sure to include in your program:

+ variables
+ at least one constant
+ loops
+ lists

To complete your program, you might also have to incorporate the other concepts you have learned in this course, such as selection (if ... then ... else statements) and nested if ... then ... else statements.

You must also ensure that

+ you complete and submit a flow chart for your program.
+ your source code includes commenting.
+ your program includes a user-friendly interface.

Being given so much freedom and choice is a great thing, but it also might be a bit of a challenge for you to come up with ideas.

The following list is meant as “creative fodder”. These are ideas, words and concepts that might help you think of what type of program you would like to create:

* Sports statistics
* Random number games
* Interesting math equations
* Populations of countries
* Computer specifications
* Statistics about animals
* Dice games
* Guess that animal games
* Distance, speed, acceleration calculator
* Multiple choice quizzes

Also, before you decide on your project idea, consider some of the assignments that you have already completed. You have created projects related to a wide variety of topics., so maybe you would like to expand on some of those ideas.




*Note for advanced students: The goal of this assignment is to show off concepts covered so far in this course. You are welcome to tie in any coding concepts that you want for your program however the main assessment will be on use of loops and lists.

When you have completed your flow chart and a description of what you want your program to do, submit your work to your teacher.
  