# Instructions  

 Putrid Pizza is a pizzeria that only makes one type of pizza with the following toppings: extra, extra anchovies and extra, extra olives.

Customers aren’t allowed to order any other type of pizza, but they are allowed to select the size (by indicating the diameter).

Your task is to `prompt the user for the diameter of pizza he or she would like to purchase, and then calculate the subtotal, the taxes, and the grand total.`

Your program should also output a message based on the following:

+ If the diameter of the pizza is from 1cm to 20 centimeters, then output a message that reads: “We are going to make you a cute little pizza!”
+ If the diameter of the pizza is greater than 20 cm but less than 40 cm, then output a message that reads: “This will be delicious!”
+ If the diameter of the pizza is greater than 40 cm, then output a message that reads: “Whoa, big pizza! You might need a truck to get this home!”

The following lists the charges for a pizza at Putrid Pizza:

$0.75 per pizza (for labour)<br>
$0.99 per pizza for rent (for the pizza shop)<br>
$0.50 per diameter centimeter of pizza (for ingredients)<br>

You will submit your completed program, as well as a flowchart that outlines the start, end, processes, input/output and decisions involved in the program.

Your program should include

+ appropriately named components.
+ commenting and appropriate spacing.
+ constants for all variables that will not change as the program is run.