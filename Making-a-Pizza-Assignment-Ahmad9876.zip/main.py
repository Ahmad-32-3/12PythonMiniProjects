# Initalizing and declaring constant variables
TAX_RATE = 0.13
LABOUR_COST = 0.75
RENT_FOR_PIZZERIA = 0.99
COST_PER_CM = 0.50

# Prompt user for diameter of pizza, then store value in diameter
diameter = int(input("\nWhat diameter is your pizza in centimeters as a rounded whole non-zero positive integer?: " ))

# Record appropriate response depending on diameter using if statements 
if diameter <= 20:
    print("\nWe are going to make you a cute little pizza!")

elif diameter <= 40:
    print("\nThis will be delicious!")

else:
    print("\nWhoa, big pizza! You might need a truck to get this home!")

# Find subtotal and total and round to the nearest hundredth 
subtotal = round(LABOUR_COST + RENT_FOR_PIZZERIA + diameter * COST_PER_CM, 2)

taxes = round(subtotal * TAX_RATE, 2)

final_total = round(subtotal + taxes, 2)

#Displaying total, subtotal and taxes
print("\nYour " + str(diameter) + " centimeter pizza has a subtotal of $" + str(subtotal) + ", the taxes are $" + str(taxes) + " and finally the final total is $" + str(final_total) + ".")