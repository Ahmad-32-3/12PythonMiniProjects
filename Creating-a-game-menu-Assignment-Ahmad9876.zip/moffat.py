from random import randint, choice

POSSIBLE_FLOWERS = ["Rose", "Lily", "Daisy", "Violet", "Tiger lily",\
                   "Cherry Blossom", "Tulip", "Poppy", "Bluebell",\
                   "Snowdrop", "Iris", "Sunflower", "Orchid"]

def random_inventory():
    inventory = []
    inventory_length = randint(2,8)
    for i in range(inventory_length):
        inventory.append(choice(POSSIBLE_FLOWERS))
    return inventory