from moffat import random_inventory, POSSIBLE_FLOWERS
from random import choice

# Adds a random number of random flowers to the starting inventory as a list
inventory = random_inventory()     

# Introduces objective
intro = """
Please enter your choice:
1… Display the inventory.

2… Pick a flower and add it to your inventory.

3… Sort inventory.

4… Say a random greeting.

9… Exit
"""

# Sets a list of numbers that are valid for the users input
options = [1,2,3,4,9]

# Initializes greetings
greetings = [
  "Good morning, welcome to the flower shop.",
  "Enjoy our extensive inventory, it may run out soon!",
  "Enjoy your time, remember that your nose is your best friend!"
]

# Puts everything in a forever loop until conditions to end it are met
while True:

  # Catches invalid inputs
  try:
    userChoice = int(input(intro))
    if userChoice not in options:
      raise ValueError
  except ValueError:
    print("Invalid input. Please try again")
    continue

  # Prints inventory
  if userChoice == 1:
    for item in inventory:
      print(item)

  # Adds a random flower to inventory
  elif userChoice == 2:
    flower = choice(POSSIBLE_FLOWERS)
    inventory.append(flower)
    print(flower + " was added to inventory.")

  # Sorts inventory
  elif userChoice == 3:
    inventory.sort()
    print("Inventory sorted.")

  # Says a random greeting
  elif userChoice == 4:
    print(choice(greetings))

  # Exits code
  else:
    print("Farewell!")
    break
