# Instructions  

You are going to create a small portion of a computer game.

Your task is to create a program that presents the user with the following user menu:

1… Display the inventory.

2… Pick a flower and add it to your inventory.

3… Sort inventory.

4… Say a random greeting.

9… Exit

The purpose of this assignment is to build your skills with while loops and for loops. You are given some starting code that sets the characters inventory, and a list of possible flowers. These have been imported for you and you don't need to edit them.

+ If the user enters option 1, each item should be printed on a new line. You will need to use a for loop to complete this.

+ If the user enters option 2, randomly add a flower from the list of POSSIBLE_FLOWERS to the inventory. You will need a new list method to do this called .append(). For example `grocery_list.append("banana")`

+ If the user enters option 3, sort the list. Use a list method to do this.

+ If the user enters option 4, print out a random greeting. You will need to create a list of greetings to do this.

Use a while loop to have the program repeat the user menu until option 9 is selected.

### Start by making your flow chart. 
Your program will involve several loops and it will be much easier to code once you have already developed the flow chart to help you think through the program outcomes.

You will submit the completed flow chart in D2L and code in Replit.

