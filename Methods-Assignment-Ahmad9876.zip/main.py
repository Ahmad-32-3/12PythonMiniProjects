from order import order_pizza


order_pizza()
print("\n\n"+"="*50 +"\n"+"\t\t\t\t\tsecond order"+"\n"+"="*50+"\n\n")
order_pizza()
