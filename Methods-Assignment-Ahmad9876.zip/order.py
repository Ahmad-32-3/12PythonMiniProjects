def order_pizza(tip=0.15):
  """function order_pizza stores code for calculating cost of pizza and reciept and returns this reciept"""
  # Initalizing and declaring constant variables
  TAX_RATE = 0.13
  LABOUR_COST = 0.75
  RENT_FOR_PIZZERIA = 0.99
  COST_PER_CM = 0.50

    # Prompt user for diameter of pizza, then store value in diameter using while loops
  while True:
    try:
      diameter = float(input("What diameter is your pizza in centimeters?: "))
      break
    except ValueError:
      print("Invalid input, please input a number.")
      continue

  # Record appropriate response depending on diameter using if statements 
  if diameter <= 20:
    print("\nWe are going to make you a cute little pizza!\n")
  elif diameter <= 40:
    print("\nThis will be delicious!\n")
  else:
    print("\nWhoa, big pizza! You might need a truck to get this home!\n")
    
  
  # Find subtotal and tax and round to the nearest hundredth 
  subtotal = (LABOUR_COST + RENT_FOR_PIZZERIA + diameter * COST_PER_CM)
  taxes = (subtotal * TAX_RATE)

  # Introduces custom tip
  custom_tip = input("Choose tip percentage, the suggested tip is 15%, if you leave this input as None then the suggested tip will be applied.(To not provide a tip input 0): ").strip()

  if custom_tip is None:
    custom_tip = tip

  # Stores custom tip
  while custom_tip:
    if custom_tip.isdigit():
      tip_percent = int(custom_tip) / 100
      tip_amount = (subtotal + taxes) * tip_percent
      print(f"Suggested tip of {tip_percent:.2f} was applied")
      break
    else:
      print("Invalid input, please try again")

  # Uses suggested tip
  if not custom_tip:
    tip_percent = tip
    tip_amount = (subtotal + taxes) * tip_percent
    print("Suggested tip of 15% was applied")

  final_total = subtotal + taxes + tip_amount
  
  # Use methods to store max lengths
  max_width = max(len(f"{subtotal:.2f}"), len(f"{taxes:.2f}"), len(f"{final_total:.2f}"), len(f"{tip_percent * 100:.0f}%"))

    
  # Set a string variable for each value
  STR_SUBTOTAL = "Subtotal"
  STR_TAXES = "Taxes"
  STR_FINAL_TOTAL = "Final Total (incl. tip)"
  STR_TIP = "Tip"
  
  # Use f-strings to format using max_width variable
  print("*************************")
  print("Receipt\n*************************")
  print(f"{STR_SUBTOTAL:<23} ${subtotal:>{max_width+1}.2f}")
  print(f"{STR_TAXES:<23} ${taxes:>{max_width+1}.2f}")
  print(f"{STR_TIP:<23} {tip_percent * 100:>{max_width}.0f}%")
  print("*************************")
  print(f"{STR_FINAL_TOTAL:<23} ${final_total:>{max_width+1}.2f}")
  
