# Instructions  

We are going to continue to build off of your pizza reciepts assignment (formatting strings). 

Put all of your previous code for the formating strings assignment inside a function called **order_pizza( )** and put this function in a new file / module called **order**. 

The function **order_pizza( )** should take no mandatory arguments but have 1 optional keyword, **tip**. tip should have a default value of 15%. 

Add a line(s) of code to your order_pizza( ) function so that a suggested tip value is included in the receipt. 

You should not need to change any code in the main file.