def findMostCalories(caloriesList):
  '''takes a list of calories and cycles through to find whichever elf has most calories'''
  
  global most
  most = 0
  
  # Defines the current total that the list repatedly adds to
  currentTotal = 0
  
  # Cycles through calories to find elf with the greatest number
  for i in range(0, len(caloriesList)):
    
# Diffrentiates between numbers and blank spaces
    if caloriesList[i] != '':
      currentTotal += int(caloriesList[i])
    elif caloriesList[i] == '' and caloriesList[i-1] != '':
      if currentTotal >= most:
        most = currentTotal
      elif currentTotal <= most:
        pass
      currentTotal = 0
      
  return most

def findSecondMostCalories(caloriesList):
  '''takes a list of calories and cycles through to find whichever elf has the second most calories'''

  global secondMost
  secondMost = 0
  currentTotal = 0

  # Ensures that the value of currentTotal is lower than the highest value before updating the total
  for i in range(0, len(caloriesList)):
    if caloriesList[i] != '':
      currentTotal += int(caloriesList[i])
    elif caloriesList[i] == '' and caloriesList[i-1] != '':
      if currentTotal < most and currentTotal >= secondMost:
        secondMost = currentTotal
      elif currentTotal <= most:
        pass
      currentTotal = 0 
      
  return secondMost

def findThirdMostCalories(caloriesList):
  '''takes a list of calories and cycles through to find whichever elf has the second most calories'''
  global thirdMost
  thirdMost = 0
  currentTotal = 0

  # Ensures that the value of currentTotal is lower than the second highest value before updating the total
  for i in range(0, len(caloriesList)):
    if caloriesList[i] != '':
      currentTotal += int(caloriesList[i])
    elif caloriesList[i] == '' and caloriesList[i-1] != '':
      if currentTotal < secondMost and currentTotal >= thirdMost:
        thirdMost = currentTotal
      elif currentTotal <= most:
        pass
      currentTotal = 0 
      
  return thirdMost