from calories import calories
import find_calories

#splits string of calories into list
caloriesList = calories.split("\n")

#use imported functions to find 1st,2nd and 3rd most calories
top1 = find_calories.findMostCalories(caloriesList)
top2 = find_calories.findSecondMostCalories(caloriesList)
top3 = find_calories.findThirdMostCalories(caloriesList)

#find total calories of top 3 elves
total = top1 + top2 + top3

#prints all the calories and the total onto screen
print(f"\n\n---------------------- Caloric Count -----------------------\n\nFirst:  {top1:43} Calories\n\nSecond: {top2:43} Calories\n\nThird:  {top3:43} Calories\n\nGrandTotal: {total:39} Calories\n\n------------------------------------------------------------")
