# Initalizing and declaring constant variables
TAX_RATE = 0.13
LABOUR_COST = 0.75
RENT_FOR_PIZZERIA = 0.99
COST_PER_CM = 0.50

# Prompt user for diameter of pizza, then store value in diameter
diameter = int(input("\tWhat diameter is your pizza in centimeters as a rounded whole non-zero positive integer?: " ))

# Record appropriate response depending on diameter using if statements 
if diameter <= 20:
    print("\n\tWe are going to make you a cute little pizza!\n")

elif diameter <= 40:
    print("\n\tThis will be delicious!\n")

elif diameter > 40:
    print("\n\tWhoa, big pizza! You might need a truck to get this home!\n")
else:
  print("Invalid input, please restart the program")
  quit()

# Find subtotal and total and round to the nearest hundredth 
subtotal = (LABOUR_COST + RENT_FOR_PIZZERIA + diameter * COST_PER_CM)

taxes = (subtotal * TAX_RATE)

final_total = (subtotal + taxes)

# Set a string variable for each value
STR_SUBTOTAL = "Subtotal"
STR_TAXES = "Taxes"
STR_FINAL_TOTAL = "Final Total"

# Setting a max-width for the receipt, this variable finds the maximum width of the subtotal, taxes and final total
max_width = max(len(f"{subtotal:.2f}"), len(f"{taxes:.2f}"), len(f"{final_total:.2f}"))

# Print the receipt using f-strings and escape characters
print("Receipt\n*************************")
print(f"{STR_SUBTOTAL:<11} ${subtotal:>{max_width+1}.2f}")
print(f"{STR_TAXES:<11} ${taxes:>{max_width+1}.2f}")
print("*************************")
print(f"{STR_FINAL_TOTAL:<11} ${final_total:>{max_width+1}.2f}")
print("\n\tUse discount code SAVE20 for 20% off your next purchase at Putrid Pizza!")
