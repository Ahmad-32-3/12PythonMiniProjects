# Instructions  

### __You have been hired by Putrid Pizza to design the receipts when customer places an order.__

Copy then edit the code you made for Putrid Pizza. 

Use the string formatting information to create a receipt that resembles a real receipt. ![image](image.png) 

+ The * character should be used to make the lines. 

+ Use f-strings to put variables in your strings

+ Prices should all contain 2 decimal places

+ Cost for labour, rent, ingredients, subtotal, tax, and grand total should all be on seperate lines.

+ Prices should all be in a column so that the numbers line up. 

Use the picture as an example. </br>
Make sure to test the code with differnt sizes of pizza to ensure the output works as expected.
